/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart1;

/**
 *
 * @author Student
 */
import java.util.Scanner;
import java.util.regex.Pattern;
public class POEPart1 {

    public static void main(String[] args) {
{
	Scanner input =new Scanner(System.in);
	
	//
	System.out.print("Enter username: ");
	String username = input.nextLine();
	
	System.out.print("Enter password: ");
	String password = input.nextLine();
	
	System.out.print("Enter cellphone number: ");
	String phone = input.nextLine();
	
	//
	//
	if (username.contains("_") && username.length() <= 5) {
	    System.out.println("Username successfully captured.");
	} else {
	    System.out.println("Username is not correctly formatted, please ensure your username contains an underscore and is no more than five characters in length.");
	}
	
	//
	boolean hasUpper = false;
	boolean hasDigit = false;
	boolean hasSpecial = false;
	
	//
	for (int i = 0; i < password.length(); i++) {
	    char c = password.charAt(i);
	    
	    if (Character.isUpperCase(c)) {
	        hasUpper = true;
	    } else if (Character.isDigit(c)) {
	        hasDigit = true;
	    } else if (!Character.isLetterOrDigit(c)) {
	        hasSpecial = true;
	    }
	    
	}
	
	//Password Validation
	if (password.length() >= 8 && hasUpper && hasDigit && hasSpecial) {
	    System.out.println("Password successfully captured.");
	} else {
	    System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number and a special character.");
	}
	
	//Phone Validation
	System.out.print("Enter cellphone number: ");
	 phone = input.nextLine();
	
	//
	String phoneRegistration = "^27\\d{8}$";
	if (Pattern.matches(phoneRegistration, phone)) {
	    System.out.println("Cellphone number succesfully added.");
	} else {
	    System.out.println("Cellphone number incorrectly formatted or does not contain international code.");
	}
	System.out.println("\n=== Login ===");
	System.out.print("Enter username: ");
	String loginUser = input.nextLine();
	System.out.print("Enter password: ");
	String loginPass = input.nextLine();
	
	//
	if (loginUser.equals(username) && loginPass.equals(password)) {
	    System.out.println("Welcome, it is great to see you again.");
	} else {
	    System.out.println("Username or password incorrect, please try again.");
	}
	}	
}


    }

